===Calculator Program===

A. Basic Program Flow
1. Input first operand
2. Select operator from dropdown
3. Input second operand
4. Click Equals for result
(note: operation dropdown resets everytime a result is produced)


B. Functionality Checklist
1. Display screen value of the value in textfield [done]
2. "0" to "9" buttons representing the numbers [done]
3. Decimal point, plus/minus sign, and equal are included as buttons [done]
4. Addition, subtraction, multiplication, division are represented as dropdown control [done]
5. Clear, delete buttons are included [done]
6. Memory add, memory minus, memory recall, memory clear button [done]
7. KeyPress [code is written but not yet working]
8. Menu bar File
	- Clear [done]
	- Exit [done]
9. Menu bar Edit
	- Copy [done]
	- Paste [done]
10. Menu bar History
	- Export to Text [done]
	- Import from Text [accomplished until calling of open dialog box]
11. History Text File (exported/imported) is formatted as sequential file [done]
12. History Grid contains three columns - Hist_ID, Hist_Action, Hist_Value [done]
13. Listbox control representing Memory Trail [done]
14. Memory Clear clears the listbox [done]
15. Memory trail is stored in array/collection and then displayed in Listbox [done]
16. Only one active instance of the program should be active [done]


C. Notes
1. User should set operation in dropdown everytime user needs a computation.
2. Memory Recall button displays the last memory stored into the Display Textbox.


Please inform me if you need anything else. Thank you.

