﻿namespace Calc
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importFromTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.memoryClrBtn = new System.Windows.Forms.Button();
            this.sevenBtn = new System.Windows.Forms.Button();
            this.memoryRecBtn = new System.Windows.Forms.Button();
            this.memoryMinusBtn = new System.Windows.Forms.Button();
            this.memoryAddBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.nineBtn = new System.Windows.Forms.Button();
            this.eightBtn = new System.Windows.Forms.Button();
            this.sixBtn = new System.Windows.Forms.Button();
            this.fiveBtn = new System.Windows.Forms.Button();
            this.fourBtn = new System.Windows.Forms.Button();
            this.threeBtn = new System.Windows.Forms.Button();
            this.twoBtn = new System.Windows.Forms.Button();
            this.oneBtn = new System.Windows.Forms.Button();
            this.decimalPointBtn = new System.Windows.Forms.Button();
            this.plusMinusBtn = new System.Windows.Forms.Button();
            this.equalsBtn = new System.Windows.Forms.Button();
            this.zeroBtn = new System.Windows.Forms.Button();
            this.dropdownOp = new System.Windows.Forms.ComboBox();
            this.displayTextBox = new System.Windows.Forms.RichTextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.historyToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(400, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToTextToolStripMenuItem,
            this.importFromTextToolStripMenuItem});
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.historyToolStripMenuItem.Text = "History";
            // 
            // exportToTextToolStripMenuItem
            // 
            this.exportToTextToolStripMenuItem.Name = "exportToTextToolStripMenuItem";
            this.exportToTextToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.exportToTextToolStripMenuItem.Text = "Export to Text";
            this.exportToTextToolStripMenuItem.Click += new System.EventHandler(this.exportToTextToolStripMenuItem_Click);
            // 
            // importFromTextToolStripMenuItem
            // 
            this.importFromTextToolStripMenuItem.Name = "importFromTextToolStripMenuItem";
            this.importFromTextToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.importFromTextToolStripMenuItem.Text = "Import from Text";
            this.importFromTextToolStripMenuItem.Click += new System.EventHandler(this.importFromTextToolStripMenuItem_Click_1);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Select Operation:";
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(282, 78);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(106, 23);
            this.clearBtn.TabIndex = 7;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // memoryClrBtn
            // 
            this.memoryClrBtn.Location = new System.Drawing.Point(15, 109);
            this.memoryClrBtn.Name = "memoryClrBtn";
            this.memoryClrBtn.Size = new System.Drawing.Size(53, 23);
            this.memoryClrBtn.TabIndex = 8;
            this.memoryClrBtn.Text = "MC";
            this.memoryClrBtn.UseVisualStyleBackColor = true;
            this.memoryClrBtn.Click += new System.EventHandler(this.memoryClrBtn_Click);
            // 
            // sevenBtn
            // 
            this.sevenBtn.Location = new System.Drawing.Point(45, 138);
            this.sevenBtn.Name = "sevenBtn";
            this.sevenBtn.Size = new System.Drawing.Size(53, 50);
            this.sevenBtn.TabIndex = 12;
            this.sevenBtn.Text = "7";
            this.sevenBtn.UseVisualStyleBackColor = true;
            this.sevenBtn.Click += new System.EventHandler(this.seven_Button_Click);
            // 
            // memoryRecBtn
            // 
            this.memoryRecBtn.Location = new System.Drawing.Point(84, 109);
            this.memoryRecBtn.Name = "memoryRecBtn";
            this.memoryRecBtn.Size = new System.Drawing.Size(53, 23);
            this.memoryRecBtn.TabIndex = 13;
            this.memoryRecBtn.Text = "MR";
            this.memoryRecBtn.UseVisualStyleBackColor = true;
            this.memoryRecBtn.Click += new System.EventHandler(this.memoryRecBtn_Click);
            // 
            // memoryMinusBtn
            // 
            this.memoryMinusBtn.Location = new System.Drawing.Point(223, 109);
            this.memoryMinusBtn.Name = "memoryMinusBtn";
            this.memoryMinusBtn.Size = new System.Drawing.Size(53, 23);
            this.memoryMinusBtn.TabIndex = 14;
            this.memoryMinusBtn.Text = "M-";
            this.memoryMinusBtn.UseVisualStyleBackColor = true;
            this.memoryMinusBtn.Click += new System.EventHandler(this.memoryMinusBtn_Click);
            // 
            // memoryAddBtn
            // 
            this.memoryAddBtn.Location = new System.Drawing.Point(152, 109);
            this.memoryAddBtn.Name = "memoryAddBtn";
            this.memoryAddBtn.Size = new System.Drawing.Size(53, 23);
            this.memoryAddBtn.TabIndex = 15;
            this.memoryAddBtn.Text = "M+";
            this.memoryAddBtn.UseVisualStyleBackColor = true;
            this.memoryAddBtn.Click += new System.EventHandler(this.memoryAddBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.Location = new System.Drawing.Point(282, 109);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(106, 23);
            this.deleteBtn.TabIndex = 16;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // nineBtn
            // 
            this.nineBtn.Location = new System.Drawing.Point(196, 138);
            this.nineBtn.Name = "nineBtn";
            this.nineBtn.Size = new System.Drawing.Size(53, 50);
            this.nineBtn.TabIndex = 17;
            this.nineBtn.Text = "9";
            this.nineBtn.UseVisualStyleBackColor = true;
            this.nineBtn.Click += new System.EventHandler(this.nineBtn_Click);
            // 
            // eightBtn
            // 
            this.eightBtn.Location = new System.Drawing.Point(119, 138);
            this.eightBtn.Name = "eightBtn";
            this.eightBtn.Size = new System.Drawing.Size(53, 50);
            this.eightBtn.TabIndex = 18;
            this.eightBtn.Text = "8";
            this.eightBtn.UseVisualStyleBackColor = true;
            this.eightBtn.Click += new System.EventHandler(this.eightBtn_Click);
            // 
            // sixBtn
            // 
            this.sixBtn.Location = new System.Drawing.Point(196, 205);
            this.sixBtn.Name = "sixBtn";
            this.sixBtn.Size = new System.Drawing.Size(53, 50);
            this.sixBtn.TabIndex = 19;
            this.sixBtn.Text = "6";
            this.sixBtn.UseVisualStyleBackColor = true;
            this.sixBtn.Click += new System.EventHandler(this.sixBtn_Click);
            // 
            // fiveBtn
            // 
            this.fiveBtn.Location = new System.Drawing.Point(119, 205);
            this.fiveBtn.Name = "fiveBtn";
            this.fiveBtn.Size = new System.Drawing.Size(53, 50);
            this.fiveBtn.TabIndex = 20;
            this.fiveBtn.Text = "5";
            this.fiveBtn.UseVisualStyleBackColor = true;
            this.fiveBtn.Click += new System.EventHandler(this.fiveBtn_Click);
            // 
            // fourBtn
            // 
            this.fourBtn.Location = new System.Drawing.Point(45, 205);
            this.fourBtn.Name = "fourBtn";
            this.fourBtn.Size = new System.Drawing.Size(53, 50);
            this.fourBtn.TabIndex = 21;
            this.fourBtn.Text = "4";
            this.fourBtn.UseVisualStyleBackColor = true;
            this.fourBtn.Click += new System.EventHandler(this.fourBtn_Click);
            // 
            // threeBtn
            // 
            this.threeBtn.Location = new System.Drawing.Point(196, 275);
            this.threeBtn.Name = "threeBtn";
            this.threeBtn.Size = new System.Drawing.Size(53, 50);
            this.threeBtn.TabIndex = 23;
            this.threeBtn.Text = "3";
            this.threeBtn.UseVisualStyleBackColor = true;
            this.threeBtn.Click += new System.EventHandler(this.threeBtn_Click);
            // 
            // twoBtn
            // 
            this.twoBtn.Location = new System.Drawing.Point(119, 275);
            this.twoBtn.Name = "twoBtn";
            this.twoBtn.Size = new System.Drawing.Size(53, 50);
            this.twoBtn.TabIndex = 24;
            this.twoBtn.Text = "2";
            this.twoBtn.UseVisualStyleBackColor = true;
            this.twoBtn.Click += new System.EventHandler(this.twoBtn_Click);
            // 
            // oneBtn
            // 
            this.oneBtn.Location = new System.Drawing.Point(45, 275);
            this.oneBtn.Name = "oneBtn";
            this.oneBtn.Size = new System.Drawing.Size(53, 50);
            this.oneBtn.TabIndex = 25;
            this.oneBtn.Text = "1";
            this.oneBtn.UseVisualStyleBackColor = true;
            this.oneBtn.Click += new System.EventHandler(this.oneBtn_Click);
            // 
            // decimalPointBtn
            // 
            this.decimalPointBtn.Location = new System.Drawing.Point(45, 345);
            this.decimalPointBtn.Name = "decimalPointBtn";
            this.decimalPointBtn.Size = new System.Drawing.Size(53, 50);
            this.decimalPointBtn.TabIndex = 26;
            this.decimalPointBtn.Text = ".";
            this.decimalPointBtn.UseVisualStyleBackColor = true;
            this.decimalPointBtn.Click += new System.EventHandler(this.button12_Click);
            // 
            // plusMinusBtn
            // 
            this.plusMinusBtn.Location = new System.Drawing.Point(196, 345);
            this.plusMinusBtn.Name = "plusMinusBtn";
            this.plusMinusBtn.Size = new System.Drawing.Size(53, 50);
            this.plusMinusBtn.TabIndex = 27;
            this.plusMinusBtn.Text = "+/-";
            this.plusMinusBtn.UseVisualStyleBackColor = true;
            this.plusMinusBtn.Click += new System.EventHandler(this.plusMinusBtn_Click);
            // 
            // equalsBtn
            // 
            this.equalsBtn.Location = new System.Drawing.Point(264, 138);
            this.equalsBtn.Name = "equalsBtn";
            this.equalsBtn.Size = new System.Drawing.Size(56, 257);
            this.equalsBtn.TabIndex = 28;
            this.equalsBtn.Text = "=";
            this.equalsBtn.UseVisualStyleBackColor = true;
            this.equalsBtn.Click += new System.EventHandler(this.equalsBtn_Click);
            // 
            // zeroBtn
            // 
            this.zeroBtn.Location = new System.Drawing.Point(119, 345);
            this.zeroBtn.Name = "zeroBtn";
            this.zeroBtn.Size = new System.Drawing.Size(53, 50);
            this.zeroBtn.TabIndex = 29;
            this.zeroBtn.Text = "0";
            this.zeroBtn.UseVisualStyleBackColor = true;
            this.zeroBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // dropdownOp
            // 
            this.dropdownOp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dropdownOp.FormattingEnabled = true;
            this.dropdownOp.Items.AddRange(new object[] {
            "Addition",
            "Subtraction",
            "Multiplication",
            "Division"});
            this.dropdownOp.Location = new System.Drawing.Point(104, 78);
            this.dropdownOp.Name = "dropdownOp";
            this.dropdownOp.Size = new System.Drawing.Size(172, 21);
            this.dropdownOp.TabIndex = 30;
            this.dropdownOp.SelectedIndexChanged += new System.EventHandler(this.dropdownOp_SelectedIndexChanged);
            // 
            // displayTextBox
            // 
            this.displayTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayTextBox.Location = new System.Drawing.Point(12, 38);
            this.displayTextBox.Name = "displayTextBox";
            this.displayTextBox.Size = new System.Drawing.Size(376, 34);
            this.displayTextBox.TabIndex = 31;
            this.displayTextBox.Text = "";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(321, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "Memory Trail";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 421);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.displayTextBox);
            this.Controls.Add(this.dropdownOp);
            this.Controls.Add(this.zeroBtn);
            this.Controls.Add(this.equalsBtn);
            this.Controls.Add(this.plusMinusBtn);
            this.Controls.Add(this.decimalPointBtn);
            this.Controls.Add(this.oneBtn);
            this.Controls.Add(this.twoBtn);
            this.Controls.Add(this.threeBtn);
            this.Controls.Add(this.fourBtn);
            this.Controls.Add(this.fiveBtn);
            this.Controls.Add(this.sixBtn);
            this.Controls.Add(this.eightBtn);
            this.Controls.Add(this.nineBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.memoryAddBtn);
            this.Controls.Add(this.memoryMinusBtn);
            this.Controls.Add(this.memoryRecBtn);
            this.Controls.Add(this.sevenBtn);
            this.Controls.Add(this.memoryClrBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Calculator";
            this.Text = "Form1";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Calculator_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button memoryClrBtn;
        private System.Windows.Forms.Button sevenBtn;
        private System.Windows.Forms.Button memoryRecBtn;
        private System.Windows.Forms.Button memoryMinusBtn;
        private System.Windows.Forms.Button memoryAddBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button nineBtn;
        private System.Windows.Forms.Button eightBtn;
        private System.Windows.Forms.Button sixBtn;
        private System.Windows.Forms.Button fiveBtn;
        private System.Windows.Forms.Button fourBtn;
        private System.Windows.Forms.Button threeBtn;
        private System.Windows.Forms.Button twoBtn;
        private System.Windows.Forms.Button oneBtn;
        private System.Windows.Forms.Button decimalPointBtn;
        private System.Windows.Forms.Button plusMinusBtn;
        private System.Windows.Forms.Button equalsBtn;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToTextToolStripMenuItem;
        private System.Windows.Forms.Button zeroBtn;
        private System.Windows.Forms.ComboBox dropdownOp;
        private System.Windows.Forms.RichTextBox displayTextBox;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem importFromTextToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

