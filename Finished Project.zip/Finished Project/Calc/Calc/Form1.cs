﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace Calc
{
    public partial class Calculator : Form
    {

        string input = string.Empty;
        string operand1 = string.Empty;
        string operand2 = string.Empty;
        char operation;
        double result;
        ArrayList a1 = new ArrayList();
        int historyID;
        string textHolder;
        ArrayList mem = new ArrayList();
        ListBox memTrail = new ListBox();
        
        public Calculator()
        {
            checkWindowOpen("Calculator");
            InitializeComponent();
            this.Text = "Calculator";

            //initialize memory trail listbox
            memTrail.Location = new Point(328, 160);
            memTrail.Size = new Size(60, 249);
            memTrail.BorderStyle = BorderStyle.Fixed3D;

            this.Controls.Add(memTrail);
            memTrail.DataSource = mem;
        }

        //one instance
        private bool checkWindowOpen(string windowName)
        {
            //check if application is already running
            for (int i = 0; i < Application.OpenForms.Count; i++)
            {
                if (Application.OpenForms[i].Name.Equals(windowName))
                {
                    Application.OpenForms[i].BringToFront();
                    return false;
                }
            }
            return true;
        }

        //function for adding history in arraylist
        private void addToHistory(ArrayList arr, int id, string action, string value)
        {
            arr.Add(id + "   " + action + "   " + value);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += ".";
            this.displayTextBox.Text += input;
        }

        private void seven_Button_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "7";
            this.displayTextBox.Text += input;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            this.input = string.Empty;
            clearDropdown();

            historyID++;
            addToHistory(a1, historyID, "Clear", "0");
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string currentString = this.displayTextBox.Text;
            string afterDelete;
            try
            {
                afterDelete = currentString.Remove(currentString.Length - 1, 1);
                this.displayTextBox.Text = afterDelete;
                this.input = afterDelete;
            }
            catch (System.ArgumentOutOfRangeException)
            {
                this.displayTextBox.Text = "";
                this.input = string.Empty;
            }
           
        }

        private void memoryMinusBtn_Click(object sender, EventArgs e)
        {
            try
            {
                mem.RemoveAt(mem.Count - 1);
            }
            catch(System.ArgumentOutOfRangeException)
            { 
                
            }
            memTrail.DataSource = null;
            memTrail.DataSource = mem;
        }

        private void memoryAddBtn_Click(object sender, EventArgs e)
        {
            mem.Add(this.displayTextBox.Text);

            memTrail.DataSource = null;
            memTrail.DataSource = mem;
        }

        private void memoryRecBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            try
            {
                this.displayTextBox.Text = mem[mem.Count - 1].ToString();
            }
            catch(System.ArgumentOutOfRangeException)
            {
               
            }
        }

        private void memoryClrBtn_Click(object sender, EventArgs e)
        {
            mem.Clear();

            memTrail.DataSource = null;
            memTrail.DataSource = mem;
        }

        private void eightBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "8";
            this.displayTextBox.Text += input;
        }

        private void nineBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "9";
            this.displayTextBox.Text += input;
        }

        private void fourBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "4";
            this.displayTextBox.Text += input;
        }

        private void fiveBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "5";
            this.displayTextBox.Text += input;
        }

        private void sixBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "6";
            this.displayTextBox.Text += input;
        }

        private void oneBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "1";
            this.displayTextBox.Text += input;
        }

        private void twoBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "2";
            this.displayTextBox.Text += input;
        }

        private void threeBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "3";
            this.displayTextBox.Text += input;
        }

        private void plusMinusBtn_Click(object sender, EventArgs e)
        {
            string currentString = this.displayTextBox.Text;
            if (currentString[0] != '-')
            {
                currentString = "-" + currentString;
            }
            else
            {
                currentString = currentString.Substring(1, currentString.Length - 1);  
            }

            this.displayTextBox.Text = currentString;
            this.input = currentString;
        }

        private void zeroBtn_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            input += "0";
            this.displayTextBox.Text += input;
        }

        private void dropdownOp_SelectedIndexChanged(object sender, EventArgs e)
        {
            dropdownOp.DropDownStyle = ComboBoxStyle.DropDownList;
            
            //get user input for selected operation
            switch(dropdownOp.SelectedIndex)
            {
                case 0:
               { 
                       operand1 = input;
                       operation = '+';
                       input = string.Empty;

                       historyID++;
                       addToHistory(a1, historyID, "Add", operand1);
                       break;
                }
                case 1:
                {
                        operand1 = input;
                        operation = '-';
                        input = string.Empty;

                        historyID++;
                        addToHistory(a1, historyID, "Subtract", operand1);
                        break;
                    }
                case 2:
                {
                        operand1 = input;
                        operation = '*';
                        input = string.Empty;

                        historyID++;
                        addToHistory(a1, historyID, "Multiply", operand1);
                        break;
                    }
                case 3:
                {
                        operand1 = input;
                        operation = '/';
                        input = string.Empty;

                        historyID++;
                        addToHistory(a1, historyID, "Divide", operand1);
                        break;
                    }
                default:
                {
                    break;
                }
            }

            this.displayTextBox.Text = "";
            this.displayTextBox.Text = operation.ToString();
            this.input = string.Empty;
        }

        private void equalsBtn_Click(object sender, EventArgs e)
        {
            operand2 = input;
            double num1, num2;
            double.TryParse(operand1, out num1);
            double.TryParse(operand2, out num2);

            if (operation == '+')
            {
                result = num1 + num2;
                displayTextBox.Text = result.ToString();
                input = result.ToString();

                historyID++;
                addToHistory(a1, historyID, "Add", operand2);

                historyID++;
                addToHistory(a1, historyID, "Equal", input);
            }
            else if (operation == '-')
            {
                result = num1 - num2;
                displayTextBox.Text = result.ToString();
                input = result.ToString();

                historyID++;
                addToHistory(a1, historyID, "Subtract", operand2);

                historyID++;
                addToHistory(a1, historyID, "Equal", input);
            }
            else if (operation == '*')
            {
                result = num1 * num2;
                displayTextBox.Text = result.ToString();
                input = result.ToString();

                historyID++;
                addToHistory(a1, historyID, "Multiply", operand2);

                historyID++;
                addToHistory(a1, historyID, "Equal", input);
            }
            else if (operation == '/')
            {
                if (num2 != 0)
                {
                    result = num1 / num2;
                    displayTextBox.Text = result.ToString();
                    input = result.ToString();

                    historyID++;
                    addToHistory(a1, historyID, "Divide", operand2);

                    historyID++;
                    addToHistory(a1, historyID, "Equal", input);
                }
                else
                {
                    displayTextBox.Text = "Error";

                    historyID++;
                    addToHistory(a1, historyID, "Divide", operand2);

                    historyID++;
                    addToHistory(a1, historyID, "Equal", "Error!");
                }

            }

            clearDropdown();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text = "";
            this.input = string.Empty;
            clearDropdown();
        }

        private void clearDropdown()
        {
            dropdownOp.Items.Clear();
            dropdownOp.Items.Add("Addition");
            dropdownOp.Items.Add("Subtraction");
            dropdownOp.Items.Add("Multiplication");
            dropdownOp.Items.Add("Division");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void importFromTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            foreach (string record in a1)
            {
                string name = saveFileDialog1.FileName;
                File.WriteAllLines(name, a1.Cast<string>().ToArray());
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textHolder = "";
            textHolder = this.displayTextBox.Text;
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.displayTextBox.Text += textHolder;
        }

        private void importFromTextToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string s = File.ReadAllText(openFileDialog1.FileName);
            this.displayTextBox.Text = s;
        }

        private void Calculator_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case (char)Keys.NumPad0:
                    {
                        displayTextBox.Text += "0";
                        break;
                    }
                case (char)Keys.NumPad1:
                    {
                        displayTextBox.Text += "1";
                        break;
                    }
                case (char)Keys.NumPad2:
                    {
                        displayTextBox.Text += "2";
                        break;
                    }
                case (char)Keys.NumPad3:
                    {
                        displayTextBox.Text += "3";
                        break;
                    }
                case (char)Keys.NumPad4:
                    {
                        displayTextBox.Text += "4";
                        break;
                    }
                case (char)Keys.NumPad5:
                    {
                        displayTextBox.Text += "5";
                        break;
                    }
                case (char)Keys.NumPad6:
                    {
                        displayTextBox.Text += "6";
                        break;
                    }
                case (char)Keys.NumPad7:
                    {
                        displayTextBox.Text += "7";
                        break;
                    }
                case (char)Keys.NumPad8:
                    {
                        displayTextBox.Text += "8";
                        break;
                    }
                case (char)Keys.NumPad9:
                    {
                        displayTextBox.Text += "9";
                        break;
                    }
                case (char)Keys.Back:
                    {
                        string currentString = this.displayTextBox.Text;
                        string afterDelete;
                        try
                        {
                            afterDelete = currentString.Remove(currentString.Length - 1, 1);
                            this.displayTextBox.Text = afterDelete;
                            this.input = afterDelete;
                        }
                        catch (System.ArgumentOutOfRangeException)
                        {
                            this.displayTextBox.Text = "";
                            this.input = string.Empty;
                        }
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }
    }
}
